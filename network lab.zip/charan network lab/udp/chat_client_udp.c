// chat_client_udp.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <unistd.h>

#define SERVER_IP "127.0.0.1"
#define PORT 12345
#define BUFFER_SIZE 1024

int main() {
    int client_socket;
    struct sockaddr_in server_addr;
    char buffer[BUFFER_SIZE];

    // Create socket
    client_socket = socket(AF_INET, SOCK_DGRAM, 0);
    if (client_socket == -1) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Configure server address
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    inet_pton(AF_INET, SERVER_IP, &server_addr.sin_addr);

    // Start the main loop to send and receive messages
    while (1) {
        printf("Enter a message (type 'exit' to quit): ");
        fgets(buffer, BUFFER_SIZE, stdin);

        if (strncmp(buffer, "exit", 4) == 0) {
            break;
        }

        // Send the message to the server
        if (sendto(client_socket, buffer, strlen(buffer), 0, (struct sockaddr *)&server_addr, sizeof(server_addr)) == -1) {
            perror("Message send failed");
            close(client_socket);
            exit(EXIT_FAILURE);
        }

        // Receive the response from the server
        int len = recvfrom(client_socket, buffer, BUFFER_SIZE, 0, NULL, NULL);
        if (len == -1) {
            perror("Receive failed");
            close(client_socket);
            exit(EXIT_FAILURE);
        }

        buffer[len] = '\0';
        printf("Received from server: %s", buffer);
    }

    close(client_socket);
    return 0;
}

