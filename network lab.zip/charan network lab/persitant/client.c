#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define SERVER_IP "127.0.0.1"
#define PORT 12345
#define MAX_BUFFER_SIZE 1024

int main() {
    int client_socket;
    struct sockaddr_in server_addr;
    char buffer[MAX_BUFFER_SIZE];

    // Create socket
    client_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (client_socket == -1) {
        perror("Error creating client socket");
        exit(EXIT_FAILURE);
    }

    // Configure server address
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = inet_addr(SERVER_IP);

    // Connect to the server
    if (connect(client_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) == -1) {
        perror("Error connecting to the server");
        close(client_socket);
        exit(EXIT_FAILURE);
    }

    printf("Connected to server at %s:%d\n", SERVER_IP, PORT);
    int count=0;
    while (1) {
        // Read input from user
        printf("Enter a message (only 3 object can be retrive): ");
        fgets(buffer, sizeof(buffer), stdin);

        // Send data to the server
        send(client_socket, buffer, strlen(buffer), 0);

        // Receive and print the response
        int bytes_received = recv(client_socket, buffer, sizeof(buffer), 0);
        if (bytes_received <= 0) {
            perror("Server disconnected");
            break;
        }

        buffer[bytes_received] = '\0';
        printf("Server response: %s\n", buffer);
        count++;

        // Check for the quit command
        if (count == 3)
            break;
    }

    // Close the client socket
    close(client_socket);

    return 0;
}

